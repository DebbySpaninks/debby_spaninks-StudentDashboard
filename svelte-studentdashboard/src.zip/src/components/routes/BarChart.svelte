<!-- Component to display BarChart -->

<script>

</script>

<main>
  <h1>Header van Staafdiagram</h1>
</main>

<style>

</style>
