<!-- Component to display Home -->

<script>

</script>

<main>
  <h1>Header van Homepage</h1>
</main>

<style>

</style>
